# Selenium Tests with the power of self-healing
This is a test automation project automating Amazon Website through Healenium.
The focus of this project is to build tests that are resistant to changes in Web elements.
Utilized Selenium, Java, Dockerized Healenium-backend for this project.
